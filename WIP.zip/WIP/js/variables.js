let x,y,z;
x=10;
y = '10';
z=30;

    console.log(`x is ${typeof x}`);
    console.log(`y is ${typeof y}`);
    console.log(`z is ${typeof z}`);
var newX = x++;

console.log(`newX is ${typeof newX}`);
console.log('x == y' + x == y);

let timeInMs = Date.now();
let min = Math.floor(timeInMs/ 60000);
let hours = Math.round(min /60);
let days = Math.round(hours/24);
let months = Math.round(days/30);
let years = Math.round(months/12);
console.log('how many years since epoch?' + years);
console.log('how many months?' + months);
console.log('how many days?'+ days);

let na = 0/0;
console.log(na);

