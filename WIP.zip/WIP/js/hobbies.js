const hobbiesArray = [
    { name: 'volleyball', lengthInYearsAtHobby: 25 },
    { name: 'cooking', lengthInYearsAtHobby: 15 },
    { name: 'swimming', lengthInYearsAtHobby: 11 }
];


function printHobbyInfo(hobby) {
    console.log(`${hobby.name} has been an interest for ${hobby.lengthInYearsAtHobby} years`)
}

for (let hobby of hobbiesArray) {
    printHobbyInfo(hobby);
}

// for (let x = 0; x < hobbiesArray.length; x++) {
//     printHobbyInfo(hobbiesArray[x]);
// }

//BONUS


hobbiesArray.forEach(hobby => {
    console.log(`  ${hobby.name} has been a hobby for  ${hobby.lengthInYearsAtHobby} years `);
});

let band1 = {
    name : "Pink Floyd",
    city : "London" ,
    country : "England",
    yearFormed : 1965,
    genres : ["Progressive rock", "psychedelic rock", "art rock"]
}
band1.genres = new Array("Progressive rock2", "psychedelic rock2", "art rock2");

let band2 = {
    name : "aha",
    city: "",
    country: "Norwegian",
    yearFormed: 1982,
    genres:["Progressive rock", "psychedelic rock", "art rock"]
}
band2.genres = new Array("Progressive rock", "psychedelic rock", "art rock");

function printBand2Info(band2) {
    console.log(`${band2.name} is from ${band2.country}`)
}